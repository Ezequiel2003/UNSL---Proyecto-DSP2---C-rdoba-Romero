from .Funciones import encontrar_bordes
