IEOSD - UNSL - DSP2 

Función para encontrar los bordes de una imagen

Implementada por los estudiantes Paul Andrés Romero Coronado (paulssj14@gmail.com) y Pablo Ezequiel Córdoba (ezequielcordoba39@gmail.com) 